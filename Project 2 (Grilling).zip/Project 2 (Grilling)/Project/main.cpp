﻿/*
 * Name: Luis Marte
 * Project 2: Grilling
 * Course: CSI218 (Spring 2025)
 * Date: THE DATE
 * Description: Cook food on a circular grill made up of sections.
 *				Grill rotates food around a flame to cook it.
 *				Food can only be placed on an empty section.  Each
 *				time step, only the section near the chef (current
*				section) is close enough to place a food item.
 *				Each type of food item has a standard grilling time
 *				(# of times circulates).  Once cooked, the item can
 *				be removed and a new item placed on the now-empty
 *				grilling section.  On occasion, grill maintenance
 *				must be performed by replacing all sections of the
 *				grill. To do so, all food on the grill is removed,
 *				sections replaced, and then the food is returned to
 *				finish cooking.
 * 
 * I try to do The bonus.
 */

#include <iostream>
#include <iomanip>
#include <cctype>
#include <string>
#include <map>
#include <queue>
#include <algorithm>
#include "circulator.cpp"
using namespace std;

// Class to hold information about food item
// that must be cooked in rotating grill.
// Also represents section of grill.
class CookableFood
{
public:
	CookableFood() : orderNum(0), itemName(""), cookTimeLeft(0) { }  // empty
	CookableFood(int initOrderNum, const string& initName, int initTime)
		: orderNum(initOrderNum), itemName(initName), cookTimeLeft(initTime) { }

	int getOrderNum() { return orderNum; }
	string getName() { return itemName; }
	int getTimeLeft() { return cookTimeLeft; }
	
	// initialize to const
	bool isEmpty() const{ return itemName == ""; }

	// Decrement cooking time left.
	// Return whether cooking is done.
	bool cook() { cookTimeLeft--; return cookTimeLeft <= 0; }

private:
	int orderNum;		// Order #
	string itemName;	// Name of item as on menu
	int cookTimeLeft;	// Rounds through grill left to be cooked
};

// Section of grill without food.
const CookableFood EMPTY_SECTION;

// Declarations for functions that grill food.

// Perform grill maintenance. Remove all the food
// temporarily, remove all the grill sections, add
// new grill sections, and place food back on grill.
// Return number of food items.
int maintainCooker(Circulator<CookableFood>& cooker);

//Helper functions to improve the program's fncionality
//Display the current state of the grill
void displayGrillState(const Circulator<CookableFood>& grill);

//Check if any section is empty
bool hasEmptySection(const Circulator<CookableFood>& grill);


int main()
{
	// Allow user to enter number of sections in grill.
	// Validate a minimum number of sections, else won't
	// form a complete circle.
	const int MIN_SECTIONS = 4;

	cout << "Number of sections in grill (at least "
		 << MIN_SECTIONS << "): ";
	int numSections;

	do
	{
		cin >> numSections;
		if (numSections < MIN_SECTIONS)
			cout << "Must have at least " << MIN_SECTIONS
			     << ". Sections: ";
		else
			break;
	} while (true);

	// Eat anything left at end of input.
	cin.ignore(numeric_limits<streamsize>::max(), '\n');

	// Circulating grill made up of sections, each possibly
	// holding food item being cooked.
	Circulator<CookableFood> grill;

	// Add requested number of sections (empty) to grill.
	for (int sectNum = 0; sectNum < numSections; sectNum++)
		grill.insertAfter(EMPTY_SECTION);

	// Menu items with cooking times (number of circulations).
	map<string, int> cookingTimes = {
		{ "burger", 5 },
		{ "hot dog", 3 },
		{ "veggie dog", 2 }
	};

	// Queue of items waiting to be cooked.
	queue<CookableFood> orders;

	// Sequential order # for each item.
	int orderNum = 0;

	do
	{
		// Display current grill state
		displayGrillState(grill);

		// Display waiting orders if any
		if (!orders.empty()) 
		{
			cout << "\nWaiting Orders: " << orders.size() << endl;
		}

		// Display menu and allow employee to enter
		// customer's order for food item to be cooked.
		cout << "\nMenu:" << endl;
		for (map<string, int>::iterator itemIter = cookingTimes.begin();
				itemIter != cookingTimes.end(); itemIter++)
			cout << itemIter->first << endl;
		cout << "or \"clean\" to clean grill" << endl;
		cout << "Item: ";
		string itemName;
		getline(cin, itemName);

		// Convert item name to lowercase.
		transform(itemName.begin(), itemName.end(), itemName.begin(),
			[](unsigned char c) { return tolower(c); });

		if (itemName == "quit") 
		{
			break;
		}
		else if (itemName == "clean")
		{
			// Peform maintenance on grill and then put back
			// any food items already on grill.
			int numFoodItems = maintainCooker(grill);
			cout << "Grill cleaned (" << numFoodItems
				<< " items placed back on grill)" << endl;
		}
		else if (!itemName.empty())  //empty
		{
			// Go to next order (only 1 item per order).
			orderNum++;

			// Check whether item entered is on menu.
			if (cookingTimes.find(itemName) == cookingTimes.end())
				cerr << "Unknown item: " << itemName << endl;
			else
			{
				// Prepare food item (uncooked).
				CookableFood item = CookableFood(orderNum, itemName, cookingTimes[itemName]);

				// Queue item for cooking.
				orders.push(item);
				cout << "Order #" << orderNum << " added to queue." << endl;

				// Place queued items on grill if there's an empty section
				if (!orders.empty() && hasEmptySection(grill)) 
				{
					CookableFood* currItem = grill.getCurrent();
					while (!currItem->isEmpty())
					{
						grill.advance();
						currItem = grill.getCurrent();
					}
					*currItem = orders.front();
					orders.pop();
					cout << "Order #" << currItem->getOrderNum()
						<< ", " << currItem->getName()
						<< " placed on grill." << endl;
				}

			}
		}

		// Check current section of grill.
		CookableFood* currItem = grill.getCurrent();

		if (currItem != nullptr)  // need at least 1 section in grill
		{
			// Check whether current section (one accessible to chef)
			// has a food item.
			if (!currItem->isEmpty())
				if (currItem->cook())  // Cook food, done?
				{
					cout << "Order #" << currItem->getOrderNum()
						 << ", " << currItem->getName()
						 << " ready!" << endl;

					// Take off grill so now section is empty.
					*currItem = EMPTY_SECTION;
				}
			    if (!orders.empty())
			    {
				    *currItem = orders.front();
				     orders.pop();
				     cout << "Order #" << currItem->getOrderNum()
				        	<< ", " << currItem->getName()
				        	<< "placed on grill." << endl;
			    }

				else // Food still cooking...
				{
					cout << "Order #" << currItem->getOrderNum()
						 << ", " << currItem->getName()
						 << " still has " << currItem->getTimeLeft()
						 << " round(s) left." << endl;
				}
		}
		// Circulate grill.
		grill.advance();

	} while (true);

	return 0;
}

// Definitions for functions that grill food.

// Perform grill maintenance. Remove all the food
// temporarily, remove all the grill sections, add
// new grill sections, and place food back on grill.
// Return number of food items.
int maintainCooker(Circulator<CookableFood>& cooker)
{
	// FILL IN FUNCTION.
	vector<CookableFood> foodItems;
	int numSections = 0;

	//Store all non-empty food items and count sections
	CookableFood* currItem = cooker.getCurrent();
	{
		do
		{
			if (currItem != nullptr && !currItem ->isEmpty())
			{
				foodItems.push_back(*currItem);
				*currItem = EMPTY_SECTION;
			}
			cooker.advance();
			currItem = cooker.getCurrent();
		} while (currItem != nullptr);

		// Clear the grill
		   cooker.clear();

		// Add new empty sections
		for (int i = 0; i < foodItems.size(); i++)
		{
			cooker.insertAfter(EMPTY_SECTION);
		}

		//Place food items back on grill
		for (int i = 0; i < foodItems.size(); i++)
		{
				
			*cooker.getCurrent() = foodItems[i];
			{
				cooker.advance();
			}		
		}
		return foodItems.size();
	}
	
}

void displayGrillState(const Circulator<CookableFood>& grill)
{
	cout << "\nGrill State:" << endl;
	cout << "\n       " << endl;

	CookableFood* start = grill.getCurrent();
	if (start != nullptr)
		CookableFood* currItem = start;
	int section = 1;
	do
	{
		cout << "Section " << section << ": ";
		if (currItem->isEmpty())
		{
			cout << "Empty" << endl;
		}
		else
		{
			cout << "Order #" << currItem->getOrderNum()
				<< " _ " << currItem->getName()
				<< " (" << currItem->getTimeLeft() << " rounds left)" << endl;
		}
		grill.advance();
		currItem = grill.getCurrent();
		section++;
	} while (currItem != start);
	cout << "   " << endl;
}

bool hasEmptySection(const Circulator<CookableFood>& grill)
{
	CookableFood* start = grill.getCurrent();
	if (start != nullptr)
	{
		CookableFood* currItem = start;
		do
		{
			if (currItem->isEmpty())
			{
				return true;
			}
			grill.advance();
			currItem = grill.getCurrent();
		} while (currItem != start);
	}
	return false;
}