/*
 * Name: Luis Marte
 * Circulator Member Function Definitions
 * Course: CSI218 (Spring 2025)
 * Date: THE DATE
 * Description: Circulator member function definitions.
 *				Circular singly-linked list implementation,
 *				maintaining a pointer to a "current" and
 *				previous node in list.
 */

#ifndef CIRCULATOR_CPP
#define CIRCULATOR_CPP

#include "circulator.h"

// Circulator member function definitions.

// Initialize to empty list.
template<class T>
Circulator<T>::Circulator()
{
	// initialize empty.
	currP = nullptr;
	//Also initialize pointer to previous node.
	prevP = nullptr;
}

// Copy constructor.
template<class T>
Circulator<T>::Circulator(const Circulator<T>& otherList)
{
	// initialize empty.
	currP = nullptr;
	prevP = nullptr;

	// Copy value of other list.
	append(otherList);
}

// Destructor.
template<class T>
Circulator<T>::~Circulator()
{
	clear();  // pointers reset once cleared
}

// Assignment operator.
template<class T>
Circulator<T>& Circulator<T>::operator =(const Circulator<T>& otherList)
{
	// Avoid copying if assigning object to self.
	if (this != &otherList)
	{
		// Empty current list.
		clear();

		// Copy values from other list.
		append(otherList);
	}

	// Return self.
	return *this;
}

// Accessors

// Get value at current position in list.
// Pointer returned so that can mutate.
// If no values in list, returns nullptr.
template<class T>
T* Circulator<T>::getCurrent() const
{
	if (currP == nullptr)
		return nullptr;
	return &currP->info;
}

// Mutators

// Insert a new value after current position in list.
// Postcondition: New value becomes current position.
template<class T>
void Circulator<T>::insertAfter(const T& val)
{
	// FILL IN FUNCTION.

	//Allocate new node and store data.
	Node* newNodeP = new Node;
	newNode->info = val;

	if (currP == nullptr)
	{
		//Empty list
		newNodeP->nextP = newNodeP; //Points to itself
		currP = newNodeP;
		prevP = newNodeP;
	}
	else
	{
		//Insert after Current node
		newNodeP->nextP = currP->nextP;
		currP->nextP = newNodeP;
		prevP = currP; // Update previous pointer
		currP = newNodeP; //Update previous pointer
	}
}

// Move to next value in the forward direction.
template<class T>
void Circulator<T>::advance()
{
	// If nodes, move current position to next one.
	// Also update pointer to node before current.
	if (currP != nullptr)
	{
		prevP = currP;
		currP = currP->nextP;
	}
}

// Remove the current value (if any) in list.
// Postcondition: Next value (after one removed)
// becomes current position.
template<class T>
bool Circulator<T>::remove()
{
	// FILL IN FUNCTION.
	if (currP == nullptr)
	{
		return false; //Nothing to remove
	}
	if (currP == currP->nextP)
	{
		//One node in list
		delete currP;
		currP = nullptr;
		prevP = nullptr;
	}
	else
	{
		//Multiple Nodes
		Node* nodeToDeLete = currP;
		prevP->nextP = currP->nextP; //skip over current node
		currP = currP->nextP; //Move to next node
		delete nodeToDeLete;
	}

	return false; //Sucessfully removed a node
}

// Remove all values from list.
template<class T>
void Circulator<T>::clear()
{
	while (remove());
}

// Insert all values from other list moving forward.
template<class T>
void Circulator<T>::append(const Circulator<T>& otherList)
{
	// BONUS: FILL IN FUNCTION.
	if (otherList.currP == nullptr) 
	{
		return; //nothing to append
	}
	Node* otherCurrP = otherList.currP;
	do 
	{
		insertAfter(otherCurr->info);
		otherCurr = otherCurr->nextp;
		while (other != otherList.currP);
	}
}

#endif