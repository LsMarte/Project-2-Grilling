/*
 * Name: Luis Marte
 * Circulator Class Definition
 * Course: CSI218 (Spring 2025)
 * Date: THE DATE
 * Description: Circulator template class definition declaring
 *				data members/member functions using type "T".
 */

#ifndef CIRCULATOR_H
#define CIRCULATOR_H
 
// Circulator template class definition that encapsulates
// a circular singly-linked list in which values can be
// added/removed. Values are added after the "current"
// position, removed at the "current" position.  The
// current position may be advanced to the next position
// in a circular fashion.
template<class T>
class Circulator
{
public:
	// Initialize as empty list.
	Circulator();

	// Copy constructor.
	Circulator(const Circulator<T>& otherList);

	// Assignment operator.
	Circulator<T>& operator =(const Circulator<T>& otherList);

	// Destructor.
	~Circulator();

	// Accessors

	// Get value at current position in list.
	// Pointer returned so that can mutate.
	// If no values in list, returns nullptr.
	T* getCurrent() const;

	// Mutators

	// Insert a new value after current position in list.
	// Postcondition: New value becomes current position.
	void insertAfter(const T& val);

	// Move to next value in the forward direction.
	void advance();

	// Remove the current value (if any) in list.
	// Postcondition: Next value (after one removed)
	// becomes current position.
	bool remove();

	// Remove all values from list.
	void clear();

private:
	struct Node
	{
		T info;
		Node* nextP;
		Node* prevP;
	};
	Node* currP;  // point to "current" position (after which add nodes)
	Node* prevP;  // point to node before "current" position (for removal)

	// Insert all values from other list moving forward.
	void append(const Circulator<T>& otherList);
};

#endif